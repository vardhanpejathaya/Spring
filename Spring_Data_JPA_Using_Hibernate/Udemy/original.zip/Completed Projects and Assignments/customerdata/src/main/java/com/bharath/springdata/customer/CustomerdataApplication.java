package com.bharath.springdata.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerdataApplication.class, args);
	}
}
