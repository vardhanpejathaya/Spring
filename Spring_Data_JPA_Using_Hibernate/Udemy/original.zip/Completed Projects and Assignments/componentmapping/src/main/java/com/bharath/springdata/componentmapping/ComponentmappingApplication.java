package com.bharath.springdata.componentmapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComponentmappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComponentmappingApplication.class, args);
	}
}
