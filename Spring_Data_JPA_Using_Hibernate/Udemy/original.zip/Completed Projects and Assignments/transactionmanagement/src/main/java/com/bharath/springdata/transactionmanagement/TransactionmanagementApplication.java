package com.bharath.springdata.transactionmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionmanagementApplication.class, args);
	}
}
