package com.bharath.springdata.jpqlandnativesql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpqlandnativesqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpqlandnativesqlApplication.class, args);
	}
}
